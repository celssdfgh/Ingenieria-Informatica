# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
#encoding:utf-8

module Civitas
class Mazo_sorpresas
  
  def init
    @sorpresas = Array.new
    @barajada = false
    @usadas = 0
    @debug = false
    @cartasEspeciales = Array.new
    @ultimasorpresa = nil
  end
  
  def initialize(deb=nil)
    if (deb != nil)
      @debug = deb
      init 
      if(deb)
        Diario.instance.ocurre_evento('Debug on')
      end
    else
      init
      @debug = false
    end
  end
  
  def al_mazo(s)
    if(!@barajada)
      @sorpresas<<s
    end
  end
  
  def siguiente()
    if((!@barajada)||(@usadas == @sorpresas.size))
      if(!debug)
        @usadas = 0
        @barajada = true
        @sorpresas.shuffle
      end
    end
    @usadas = @usadas + 1
    @ultimasorpresa = @sorpresas[0]
    @sorpresas<<@ultiamsorpresa
    return @ultimasorpresa
  end
  
  def inhabilitar_cartaespecial(sorpresa)
    for i in 0...@sorpresas.size
      if(@sorpresas[i]==sorpresa)
        y = @sorpresas[i]
        @sorpresas.delete_at(i)
        @cartasEspeciales<<y
        Diario.instance.ocurre_evento('Inhabilitado carta del mazo sorpresas. Se ha anadido a cartas especiales')
      end
    end
  end
  
  def habilitar_cartaespecial(sorpresa)
    for i in 0...@cartasEspeciales.size
      if(@cartasEspeciales[i]==sorpresa)
        x = @cartasEspeciales[i]
        @cartasEspeciales.delete_at(i)
        @sorpresas<<x
        Diario.instance.ocurre_evento('Habilitado carta proveniente de cartas especiales al mazo sorpresas')
      end
    end
  end
  
  
  private :init
end
end
