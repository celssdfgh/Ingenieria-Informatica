# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class SorpresaSalirCarcel < Sorpresa
  
  def initialize(mazo1, texto)
    super(texto)
    @mazo = mazo1
  end
  
  def to_string
    return "Sorpresa Salir Carcel"
  end
  
  def salir_del_mazo
    @mazo.habilitar_cartaespecial(self)
  end
  
  def usada
    mazo.inhabilitar_cartaespecial(self)
  end
  
  def aplicar_a_jugador(actual,todos)
    if(jugador_correcto(actual,todos))
      super(actual, todos)
      salvar = false
      
      for i in 0...todos.size
        if(todos[i].tiene_salvoconducto)
          salvar = true
        end
      end
      if(!salvar)
        todos[actual].obtener_salvoconducto(self)
        salir_del_mazo
      end
    end
  end
  
  public_class_method :new
end
end
