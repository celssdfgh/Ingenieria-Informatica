# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative ('sorpresa')
require_relative ('jugador')

module Civitas
class Sorpresa
  
  def initialize(texto1)
    @texto = texto1
  end
  
  def jugador_correcto(actual,todos)
    return actual <= todos.size
  end
  
  def informe(actual,todos)
    t = "Se esta aplicando una sorpresa a " + todos[actual].nombre + "..."
    puts t
    Diario.instance.ocurre_evento(t)
  end
  
  def aplicar_a_jugador(actual,todos)
    informe(actual,todos)
  end
  
  def to_string
    return "Texto = " + @texto
  end
  
  private_class_method :new
  private :informe
end
end
