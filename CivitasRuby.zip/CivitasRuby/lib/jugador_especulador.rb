# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class JugadorEspeculador < Jugador
  
  @@FactorEspeculador = 2
  
  def initialize(jugador1, fianza1)
    jugador_copia(jugador1)
    @fianza = fianza1
    @especulador = true
  end
  
  def to_string
    cadena3 = "Jugador Especulador [ " + "fianza = " + @fianza + ", encarcelado = " + @encarcelado + ", nombre = " + @nombre + ", salvoconducto = " + @salvoconducto + ", saldo = " + @saldo + ", puede comprar = " + @puedeComprar + ", casilla actual = " + @numCasillaActual + ", propiedades = "
    for i in 0...@propiedades.size
      cadena3 = cadena3 + @propiedades[i].nombre
    end
    return cadena3
  end
  
  def get_casas_max
    return @@CasasMax*@@FactorEspeculador
  end
  
  def get_hoteles_max
    return @@HotelesMax*@@FactorEspeculador
  end
  
  def debe_ser_encarcelado
    if(@encarcelado)
      return false
    else
      if(tiene_salvoconducto)
        perder_salvoconducto
        Diario.instance.ocurre_evento(@nombre + " ha usado salvoconducto")
        return false
      else
        if(puede_pagar_fianza)
          paga(@fianza)
          return false
        end
      end
    end
    return true
  end
  
  def puede_pagar_fianza
    paga = false
    
    if(@saldo >= @fianza)
      modificar_saldo(-@fianza)
      paga = true
    end
    return paga
  end
  
  def puedo_edificar_casa(propiedad)
    if(@encarcelado)
      return false
    end
    
    if(propiedad.nCasas < get_casas_max)
      return @saldo >= propiedad.precioedificar
    else
      return false
    end
  end
  
  def puedo_edificar_hotel(propiedad)
    if(@encarcelado)
      return false
    end
    
    if(propiedad.nHoteles < get_hoteles_max)
      return @saldo >= propiedad.precioedificar
    else
      return false
    end
  end
  
  def paga_impuesto(cantidad)
    if(@encarcelado)
      return false
    else
      return paga(cantidad/@@FactorEspeculador)
    end
  end
  
  
end
end
