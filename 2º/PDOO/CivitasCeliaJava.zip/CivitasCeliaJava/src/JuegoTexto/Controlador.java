package JuegoTexto;


import civitas.CivitasJuego;
import civitas.GestionesInmobiliarias;
import civitas.OperacionInmobiliaria;
import civitas.OperacionesJuego;
import civitas.Respuestas;
import civitas.SalidasCarcel;

public class Controlador {
    
    CivitasJuego juego;
    VistaTextual vista;
    
    Controlador(CivitasJuego juego, VistaTextual vista){
        this.juego = juego;
        this.vista = vista;
    }
    
    void juega(){
         vista.setCivitasJuego(juego);        
         while(vista.juegoModel.finalDelJuego() == false){            
             System.out.println("");
             vista.actualizarVista();            
             vista.pausa();            
             OperacionesJuego siguiente = vista.juegoModel.siguientePaso();            
             vista.mostrarSiguienteOperacion(siguiente);            
             if(siguiente != OperacionesJuego.PASAR_TURNO){                
                 vista.mostrarEventos();
             }            
             boolean fin = vista.juegoModel.finalDelJuego();            
             if(fin == false){                
                 if(siguiente == OperacionesJuego.COMPRAR){                    
                     Respuestas respuesta = vista.comprar();
                     if(respuesta == Respuestas.SI){                        
                         vista.juegoModel.comprar();
                         vista.juegoModel.siguientePasoCompletado(OperacionesJuego.COMPRAR);                    
                     }
                     else{                        
                         vista.juegoModel.siguientePasoCompletado(OperacionesJuego.COMPRAR);                    
                     }                
                 }
                 else if(siguiente == OperacionesJuego.GESTIONAR){                    
                     vista.gestionar();                    
                     OperacionInmobiliaria operacion = new OperacionInmobiliaria(GestionesInmobiliarias.values()[vista.getGestion()], vista.getPropiedad());                    
                     System.out.println(operacion.getNumPropiedad() + " es la propiedad");                    
                     if(operacion.getGestion() == GestionesInmobiliarias.CANCELAR_HIPOTECA){                        
                         vista.juegoModel.cancelarHipoteca(operacion.getNumPropiedad());                    
                     }
                     else if(operacion.getGestion() == GestionesInmobiliarias.CONSTRUIR_CASA){                        
                         vista.juegoModel.construirCasa(operacion.getNumPropiedad());                    
                     }
                     else if(operacion.getGestion() == GestionesInmobiliarias.CONSTRUIR_HOTEL){                        
                         vista.juegoModel.construirHotel(operacion.getNumPropiedad());                    
                     }
                     else if(operacion.getGestion() == GestionesInmobiliarias.HIPOTECAR){                        
                         vista.juegoModel.hipotecar(operacion.getNumPropiedad());                    
                     }
                     else if(operacion.getGestion() == GestionesInmobiliarias.VENDER){                        
                         vista.juegoModel.vender(operacion.getNumPropiedad());                    
                     }
                     else if(operacion.getGestion() == GestionesInmobiliarias.TERMINAR){                        
                         vista.juegoModel.siguientePasoCompletado(OperacionesJuego.GESTIONAR);                    
                     }               
                 }
                 else if(siguiente == OperacionesJuego.SALIR_CARCEL){                    
                     SalidasCarcel salida = vista.salirCarcel();                    
                     if(salida == SalidasCarcel.PAGANDO){                        
                         vista.juegoModel.salirCarcelPagando();                    
                     }
                     else{  
                         vista.juegoModel.salirCarcelTirando();                    
                     }                    
                     vista.juegoModel.siguientePasoCompletado(OperacionesJuego.SALIR_CARCEL);                
                 }            
             }        
         }        
         vista.juegoModel.ranking();    
    }
}
