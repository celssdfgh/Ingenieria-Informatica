/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author celss
 */
public class TituloPropiedad {
    private float alquilerBase;
    private static float factorInteresesHipoteca = 1.1f;
    private float factorRevalorizacion;
    private float hipotecaBase;
    private Boolean hipotecado;
    public String nombre;
    private int numCasas;
    private int numHoteles;
    private float precioCompra;
    private float precioEdificar;
    private Jugador propietario;
    
    TituloPropiedad(String nom, float ab, float fr, float hb, float pc, float pe){
        nombre = nom;
        alquilerBase = ab;
        factorRevalorizacion = fr;
        hipotecaBase = hb;
        precioCompra = pc;
        precioEdificar = pe;
        propietario = null;
        hipotecado = false;
        numCasas = 0;
        numHoteles = 0;
    }
    
    public Boolean getHipotecado(){
        return hipotecado;
    }
    
    float getImporteCancelarHipoteca(){
        return getImporteHipoteca()*factorInteresesHipoteca;
    }
    
    float getImporteHipoteca(){
        return hipotecaBase*(1f+(numCasas*0.5f)+(numHoteles*2.5f));
    }
    
    String getNombre(){
        return nombre;
    }
    
    int getNumCasas(){
        return numCasas;
    }
    
    int getNumHoteles(){
        return numHoteles;
    }
    
    float getPrecioAlquiler(){
        if(!hipotecado && !propietarioEncarcelado()){
            return alquilerBase*(1f+(numCasas*0.5f)+(numHoteles*2.5f));
        }
        else{
            return 0;
        }
    }
    
    float getPrecioCompra(){
        return precioCompra;
    }
    
    float getPrecioEdificar(){
        return precioEdificar;
    }
    
    float getPrecioVenta(){
        return precioCompra+(numCasas+5f*numHoteles)*precioEdificar*factorRevalorizacion;
    }
    
    Jugador getPropietario(){
        return propietario;
    }
    
    Boolean tienePropietario(){
        return propietario != null;
    }
    
    int cantidadCasasHoteles(){
        return numCasas + numHoteles;
    }
    
    Boolean esEsteElPropietario(Jugador jugador){
        return jugador == propietario;
    }
    
    Boolean propietarioEncarcelado(){
        if(tienePropietario()){
            return propietario.isEncarcelado();
        }
        else{
            return false;
        }
    }
    
    void tramitarAlquiler(Jugador jugador){
        if(tienePropietario() && !esEsteElPropietario(jugador)){
            jugador.pagaAlquiler(getPrecioAlquiler());
            propietario.recibe(getPrecioAlquiler());
        }
    }
    
    Boolean derruirCasas(int n, Jugador jugador){
        if(esEsteElPropietario(jugador) && numCasas >= n){
            numCasas = numCasas - n;
            return true;
        }
        else{
            return false;
        }
    }
    
    Boolean vender(Jugador jugador){
        if(esEsteElPropietario(jugador) && !hipotecado){
            jugador.recibe(getPrecioVenta());
            propietario = null;
            numCasas = 0;
            numHoteles = 0;
            return true;
        }
        else{
            return false;
        }
    }
    
    void actualizaJugadorPorConversion(Jugador jugador){
        propietario = jugador;
    }
    
    Boolean hipotecar(Jugador jugador){
        Boolean operacionRealizada = false;
        if(!hipotecado && esEsteElPropietario(jugador)){
            propietario.recibe(getImporteHipoteca());
            hipotecado = true;
            operacionRealizada = true;
        }
        return operacionRealizada;
    }
    
    Boolean construirHotel(Jugador jugador){
        if(esEsteElPropietario(jugador)){
            propietario.paga(precioEdificar);
            numHoteles++;
            return true;
        }
        else{
            return false;
        }
    }
    
    Boolean construirCasa(Jugador jugador){
        if(esEsteElPropietario(jugador)){
            propietario.paga(precioEdificar);
            numCasas++;
            return true;
        }
        else{
            return false;
        }
    }
    
    Boolean comprar(Jugador jugador){
        if(!tienePropietario()){
            actualizaJugadorPorConversion(jugador);
            propietario.paga(getPrecioCompra());
            return true;
        }
        else{
            return false;
        }
    }
    
    Boolean cancelarHipoteca(Jugador jugador){
        if(getHipotecado() && esEsteElPropietario(jugador)){
            propietario.paga(getImporteCancelarHipoteca());
            hipotecado = false;
            return true;
        }
        else{
            return false;
        }
    }
    
    @Override
    public String toString(){
        String mensaje;
        String prop;
        String hipo;
        if(!tienePropietario()){
            prop = "\nNo tiene propietario";
        }
        else{
            prop = "\nPropietario: " + propietario.getNombre();
        }
        if(hipotecado){
            hipo = "hipotecada";
        }
        else{
            hipo = "no hipotecada";
        }
        
        mensaje = "\nNombre: " + nombre + "\nAlquiler base: " + alquilerBase + "\nFactor intereses hipoteca: " + factorInteresesHipoteca
                + "\nFactor de revalorización: " + factorRevalorizacion + "\nHipoteca base: " + hipotecaBase + "\nEstado hipoteca: " + hipo +
                "\nNúmero de casas: " + numCasas + "\nNúmero de hoteles: " + numHoteles + "\nPrecio de compra: " + precioCompra + "\nPrecio de edificación: "
                + precioEdificar + prop;
        
        return mensaje;
    }
}
