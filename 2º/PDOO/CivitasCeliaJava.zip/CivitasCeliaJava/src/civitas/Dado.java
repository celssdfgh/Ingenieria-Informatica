/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;
import java.util.Random;

public class Dado {
    private Random random;
    private int ultimoResultado;
    private boolean debug;
    private static Dado instance = new Dado();
    private static int SalidaCarcel = 5;
    
    private Dado(){
        debug = false;
        ultimoResultado = 0;
        random = new Random();
    }
    
    static public Dado getInstance(){
        return instance;
    }
    
    int tirar(){
        if(!debug){
            int tiro = random.nextInt(6) + 1;
            ultimoResultado = tiro;
            return tiro;
        }
        else{
            ultimoResultado = 1;
            return 1;
        }
    }
    
    Boolean salgoDeLaCarcel(){
        if(tirar() == SalidaCarcel){
            return true;
        }
        else{
            return false;
        }
    }
    
    int quienEmpieza(int n){
        return random.nextInt(n);
    }
    
    public void setDebug(Boolean d){
        debug = d;
        if(debug){
            Diario.getInstance().ocurreEvento("Dado en modo debug");
        }
        else{
            Diario.getInstance().ocurreEvento("Dado en modo normal");
        }
    }
    
    int getUltimoResultado(){
        return ultimoResultado;
    }
}
