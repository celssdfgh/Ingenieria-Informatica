package civitas;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celss
 */
public class Tablero {
    private int numCasillaCarcel;
    private int porSalida;
    private ArrayList <Casilla> casillas;
    private Boolean tieneJuez;
    
    public Tablero(int carcel){
        if(carcel >= 1){
            numCasillaCarcel = carcel;
        }
        else{
            numCasillaCarcel = 1;
        }
        
        this.casillas = new ArrayList<>();
        
        Casilla salida;
        salida = new Casilla("Salida");
        this.casillas.add(salida);
        
        porSalida = 0;
        tieneJuez = false;
    }
    
    private Boolean correcto(){
        return casillas.size() > numCasillaCarcel && tieneJuez;
    }
    
    private Boolean correcto(int numCasilla){
        return correcto() && numCasilla >= 0 && numCasilla < casillas.size();
    }
    
    int getCarcel(){
        return numCasillaCarcel;
    }
    
    int getPorSalida(){
        if(porSalida > 0){
            porSalida--;
            return porSalida+1;
        }
        else{
            return porSalida;
        }
    }
    
    void añadeCasilla(Casilla casilla){
        if(casillas.size() == numCasillaCarcel){
            casillas.add(new Casilla("Carcel"));
        }
         if (casilla instanceof CasillaJuez){            
             añadeJuez();        
         } 
         else {            
             casillas.add(casilla);        
         }        
         if (casillas.size() == numCasillaCarcel){            
             Casilla Carcel = new Casilla("Carcel");            
             casillas.add(Carcel);        
         }
    }
    
    void añadeJuez(){
        if(!tieneJuez){
            añadeCasilla(new Casilla("Juez"));
            tieneJuez = true;
        }
    }
    
    Casilla getCasilla (int numCasilla){
        if(correcto(numCasilla)){
            return casillas.get(numCasilla);
        }
        else{
            return null;
        }
    }
    
    int nuevaPosicion(int actual, int tirada){
        if(!correcto()){
            return -1;
        }
        else{
            int pos;
            pos = actual + tirada;
            
            if(pos > casillas.size()){
                pos = pos % casillas.size();
                porSalida++;
            }
            
            return pos;
        }
    }
    
    int calcularTirada(int origen, int destino){
        int tirada = destino - origen;
        if(tirada < 0){
            tirada = tirada + casillas.size();
        }
        return tirada;
    }
    
    ArrayList <Casilla> getCasillas(){
        return casillas;
    }
    
}
