/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import static java.lang.Float.compare;
import java.util.ArrayList;

/**
 *
 * @author celss
 */
public class Jugador implements Comparable<Jugador> {
    protected static int CasasMax = 4;
    protected static int CasasPorHotel = 4;
    protected Boolean encarcelado;
    protected static int HotelesMax = 4;
    private String nombre;
    private int numCasillaActual;
    protected static float PasoPorSalida = 1000f;
    protected static float PrecioLibertad = 200f;
    Boolean puedeComprar;
    private float saldo;
    private static float SaldoInicial = 7500f;
    private SorpresaSalirCarcel salvoconducto = null;
    private ArrayList<TituloPropiedad> propiedades = new ArrayList<>();

    
    Jugador(String nombre){
        encarcelado = false;
        this.nombre = nombre;
        numCasillaActual = 0;
        puedeComprar = true;
        saldo = SaldoInicial;
    }
    
    protected Jugador(Jugador otro){
        encarcelado = otro.encarcelado;
        nombre = otro.nombre;
        numCasillaActual = otro.numCasillaActual;
        puedeComprar = otro.puedeComprar;
        saldo = otro.saldo;
        salvoconducto = otro.salvoconducto;
        propiedades = otro.propiedades;
    }
    
    Boolean hipotecar(int ip){
       Boolean result = false;        
       if (!encarcelado){            
           if (existeLaPropiedad(ip)){                
               TituloPropiedad propiedad = propiedades.get(ip);
               result = propiedad.hipotecar(this);            
           } 
        }
       if (result){            
           Diario.getInstance().ocurreEvento("El jugador "+nombre+" hipoteca la propiedad "+ip);        
       }        
       return result;
    }
    
    Boolean cancelarHipoteca(int ip){
         Boolean result = false;        
         if (!encarcelado){            
             if (existeLaPropiedad(ip)){                
                 TituloPropiedad propiedad = propiedades.get(ip);                
                 float cantidad = propiedad.getImporteCancelarHipoteca();                
                 Boolean puedoGastar = puedoGastar(cantidad);                
                 if (puedoGastar){                    
                     result = propiedad.cancelarHipoteca(this);                    
                     if (result){                        
                         Diario.getInstance().ocurreEvento("El jugador "+nombre+" cancela la hipoteca de la propiedad "+ip);                    
                     }                
                 }            
             }        
         }        
         return result;
    }
    
    Boolean comprar(TituloPropiedad titulo){
        Boolean result = false;        
        if (!encarcelado && !titulo.tienePropietario()){            
            if (puedeComprar){                
                float precio = titulo.getPrecioCompra();               
                if (puedoGastar(precio)){                   
                    result = titulo.comprar(this);                   
                    if (result){                       
                        propiedades.add(titulo);                       
                        Diario.getInstance().ocurreEvento("El jugador "+nombre+" compra la propiedad "+titulo.toString());                   
                    }                   
                    puedeComprar = false;               
                }            
            }        
        }        
        return result;
    }
    
    Boolean construirCasa(int ip){
        Boolean result = false;        
        Boolean puedoEdificarCasa = false;        
        if (!encarcelado){            
            Boolean existe = existeLaPropiedad(ip);            
            if (existe){                
                TituloPropiedad propiedad = propiedades.get(ip);                
                puedoEdificarCasa = puedoEdificarCasa(propiedad);                
                if (puedoEdificarCasa){                    
                    result = propiedad.construirCasa(this);                    
                    if (result){                        
                        Diario.getInstance().ocurreEvento("El jugador "+nombre+" construye casa en la propiedad "+ip);                    
                    }                
                }            
            }        
        }        
        return result;
    }
    
    Boolean construirHotel(int ip){
        Boolean result = false;
        if(!encarcelado){
            if (existeLaPropiedad(ip)){                
                TituloPropiedad propiedad = propiedades.get(ip);                
                Boolean puedoEdificarHotel = puedoEdificarHotel(propiedad);                
                if (puedoEdificarHotel){                    
                    result = propiedad.construirHotel(this);                   
                    int casasPorHotel = getCasasPorHotel();                    
                    propiedad.derruirCasas(casasPorHotel, this);                
                }                
                Diario.getInstance().ocurreEvento("El jugador "+nombre+" construye hotel en la propiedad "+ip);            
            }        
        }        
        return result;
    }
    
    int getCasasMax(){
        return CasasMax;
    }
    
    Boolean isEncarcelado(){
        return encarcelado;
    }
    
    int getCasasPorHotel(){
        return CasasPorHotel;
    }
    
    int getHotelesMax(){
        return HotelesMax;
    }
    
    protected String getNombre(){
        return nombre;
    }
    
    int getNumCasillaActual(){
        return numCasillaActual;
    }
    
    private float getPrecioLibertad(){
        return PrecioLibertad;
    }
    
    private float getPremioPasoSalida(){
        return PasoPorSalida;
    }
    
    public ArrayList<TituloPropiedad> getPropiedades(){
        return propiedades;
    }
    
    Boolean getPuedeComprar(){
        return puedeComprar;
    }
    
    protected float getSaldo(){
        return saldo;
    }
    
    Boolean tieneSalvoconducto(){
        return salvoconducto != null;
    }
    
    Boolean debeSerEncarcelado(){
        if(encarcelado){
            return false;
        }
        else if(!tieneSalvoconducto()){
            return true;
        }
        else{
           perderSalvoconducto();
           Diario.getInstance().ocurreEvento("El jugador " +getNombre() +" ha perdido la carta para escapar de la carcel.");
           return false;
        }
    }
    
    Boolean encarcelar(int numCasillaCarcel){
        if(debeSerEncarcelado()){
            moverACasilla(numCasillaCarcel);
            encarcelado = true;
            Diario.getInstance().ocurreEvento("Se ha encarcelado al jugador " +getNombre());
        }
        
        return encarcelado;
    }
    
    Boolean obtenerSalvoconducto(SorpresaSalirCarcel s){
        if(encarcelado){
            return false;
        }
        else{
            salvoconducto = s;
            return true;
        }
    }
    
    void perderSalvoconducto(){
        salvoconducto.usada();
        salvoconducto = null;
    }
    
    Boolean puedeComprarCasilla(){
        puedeComprar = !encarcelado;
        return puedeComprar;
    }
    
    Boolean paga(float cantidad){
        return modificarSaldo(cantidad*-1);
    }
    
    Boolean modificarSaldo(float cantidad){
        saldo += cantidad;
        Diario.getInstance().ocurreEvento("Se ha modificado el saldo del jugador " +getNombre() +" en la cantidad " +cantidad);
        return true;
    }
    
    Boolean moverACasilla(int numCasilla){
        if(encarcelado){
            return false;
        }
        else{
            numCasillaActual = numCasilla;
            puedeComprar = false;
            Diario.getInstance().ocurreEvento("El jugador " +getNombre() +" se ha movido a la casilla " +numCasilla);
            return true;
        }
    }
    
    Boolean puedoGastar(float precio){
        if(!encarcelado){
            return saldo >= precio;
        }
        else{
            return false;
        }
    }
    
    Boolean existeLaPropiedad(int ip){
        return ip >= 0 && ip < propiedades.size();
    }
    
    Boolean vender(int ip){
        if(!encarcelado){
            if(existeLaPropiedad(ip)){
                if(propiedades.get(ip).vender(this)){
                    propiedades.remove(ip);
                    Diario.getInstance().ocurreEvento("Se ha vendido la propiedad " +propiedades.get(ip).getNombre() +" del jugador " +getNombre());
                    return true;
                }
            }
        }
        return false;
    }
    
    Boolean tieneAlgoQueGestionar(){
        return (propiedades.size() > 0);
    }
    
    Boolean puedeSalirCarcelPagando(){
        return saldo >= PrecioLibertad;
    }
    
    Boolean salirCarcelPagando(){
        if(encarcelado && puedeSalirCarcelPagando()){
            paga(PrecioLibertad);
            encarcelado = false;
            Diario.getInstance().ocurreEvento("El jugador " +getNombre() +" ha salido de la carcel pagando.");
            return true;
        }
        return false;
    }
    
    Boolean salirCarcelTirando(){
        if(Dado.getInstance().salgoDeLaCarcel() && encarcelado){
            encarcelado = false;
            Diario.getInstance().ocurreEvento("El jugador " +getNombre() +" ha salido de la carcel tirando");
            return true;
        }
        return false;
    }
    
    Boolean pasaPorSalida(){
        modificarSaldo(PasoPorSalida);
        Diario.getInstance().ocurreEvento("El jugador " +getNombre() +" ha pasado por la salida.");
        return true;
    }
    
    int cantidadCasasHoteles(){
        int total = 0;
        for(int i = 0; i < propiedades.size(); i++){
            total += propiedades.get(i).getNumCasas() + propiedades.get(i).getNumHoteles();
        }
        return total;
    }
    
    Boolean pagaImpuesto(float cantidad){
        if(!encarcelado){
            return paga(cantidad);
        }
        return false;
    }
    
    Boolean pagaAlquiler(float cantidad){
        if(!encarcelado){
            return paga(cantidad);
        }
        return false;
    }
    
    Boolean recibe(float cantidad){
        if(!encarcelado){
            return modificarSaldo(cantidad);
        }
        return false;
    } 
    
    private Boolean puedoEdificarCasa(TituloPropiedad propiedad){
        Boolean puedoEdificarCasa = false;        
        float precio = propiedad.getPrecioEdificar();        
        if (puedoGastar(precio) && propiedad.getNumCasas() < getCasasMax()){            
            puedoEdificarCasa = true;        }        
        return puedoEdificarCasa;
    }
    
    private Boolean puedoEdificarHotel(TituloPropiedad propiedad){
        Boolean puedoEdificarHotel = false;        
        float precio = propiedad.getPrecioEdificar();        
        if (puedoGastar(precio)){            
            if (propiedad.getNumHoteles() < getHotelesMax()){                
                if (propiedad.getNumCasas() >= getCasasPorHotel()){                    
                    puedoEdificarHotel = true;                
                }            
            }        
        }        
        return puedoEdificarHotel;
    }
    
    Boolean enBancarrota(){
        return saldo <= 0;
    }
    
    @Override
    public int compareTo(Jugador otro) {
        return compare(saldo, otro.saldo);
    }
    
    @Override
    public String toString(){
        return "Jugador{ nombre=" + nombre + ", encarcelado=" + encarcelado +  ", numCasillaActual=" + numCasillaActual + ", puedeComprar=" + puedeComprar + ", saldo=" + saldo +"}";
    }
    
}
