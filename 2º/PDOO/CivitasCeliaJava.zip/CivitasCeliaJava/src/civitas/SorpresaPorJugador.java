/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author celss
 */
public class SorpresaPorJugador extends Sorpresa{
    private int valor;
    
    SorpresaPorJugador(int valor, String texto){
        super(texto);
        this.valor = valor;
    }
    
    @Override
    void aplicarAJugador(int actual, ArrayList<Jugador> todos){
        if (jugadorCorrecto(actual, todos)){            
            informe(actual, todos);            
            SorpresaPagarCobrar s1 = new SorpresaPagarCobrar(valor * -1, "PAGARCOBRAR");            
            for (int i = 0; i < actual; i++){                
                s1.aplicarAJugador(i, todos);            
            }            
            for (int i = actual + 1; i < todos.size(); i++){                
                s1.aplicarAJugador(i, todos);            
            }            
            SorpresaPagarCobrar s2 = new SorpresaPagarCobrar(valor * (todos.size() - 1), "PAGARCOBRAR");            
            s2.aplicarAJugador(actual, todos);        
        }
    }
    
    @Override
    public String toString(){
         return "Sorpresa{" + "texto=" + super.getTexto() + ", valor=" + Integer.toString(valor) + "}";
    }
}
