/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;
import java.util.ArrayList;
/**
 *
 * @author celss
 */
public class SorpresaSalirCarcel extends Sorpresa{
    private MazoSorpresas mazo;
    
    SorpresaSalirCarcel(MazoSorpresas mazo){
        super("Escapas de la carcel");
        this.mazo = mazo;
    }
    
    void salirDelMazo(){
        mazo.inhabilitarCartaEspecial(this);
    }
    
    void usada(){
        mazo.habilitarCartaEspecial(this);
    }
    
    @Override
    void aplicarAJugador(int actual, ArrayList<Jugador> todos){
        if (jugadorCorrecto(actual, todos)){            
            informe(actual, todos);            
            Boolean poseido = false;            
            for (int i = 0; i < todos.size(); i++){                
                if (todos.get(i).tieneSalvoconducto() == true){                    
                    poseido = true;                
                }            
            }            
            if (!poseido){                
                todos.get(actual).obtenerSalvoconducto(this);                
                salirDelMazo();            
            }        
        }
    }
    
    @Override 
    public String toString(){
        return "Sorpresa{" + "texto=" + super.getTexto() + "}";
    }
}
