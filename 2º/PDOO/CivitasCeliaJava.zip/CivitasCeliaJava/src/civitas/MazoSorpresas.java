/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;
import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author celss
 */
public class MazoSorpresas {
    private ArrayList<Sorpresa> sorpresas;
    private Boolean barajada;
    private int usadas;
    private Boolean debug;
    private ArrayList<Sorpresa> cartasEspeciales;
    private Sorpresa ultimaSorpresa;
    
    private void init(){
        barajada = false;
        usadas = 0;
        sorpresas = new ArrayList<>();
        cartasEspeciales = new ArrayList<>();
    }
    
    MazoSorpresas(Boolean d){
        debug = d;
        init();
        
        if(d){
            Diario.getInstance().ocurreEvento("Modo debug en mazo");
        }
    }
    
    MazoSorpresas(){
        debug = false;
        init();
    }
    
    void alMazo(Sorpresa s){
        if(!barajada){
            sorpresas.add(s);
        }
    }
    
    Sorpresa siguiente(){
        if(!barajada || usadas == sorpresas.size() && !debug){
            usadas = 0;
            barajada = true;
            Collections.shuffle(sorpresas);
        }
        
        usadas++;
        
        Sorpresa s = sorpresas.get(0);
        sorpresas.add(s);
        sorpresas.remove(0);
        
        ultimaSorpresa = s;
        return ultimaSorpresa;
    }
    
    void inhabilitarCartaEspecial(Sorpresa sorpresa){
        for(int i = 0; i < sorpresas.size(); i++){
            
            if(sorpresa == sorpresas.get(i)){
                cartasEspeciales.add(sorpresas.get(i));
                sorpresas.remove(i);
                
                Diario.getInstance().ocurreEvento("Se ha movido una carta a cartas especiales");
            }
        }
    }
    
    void habilitarCartaEspecial(Sorpresa sorpresa){
        for(int i = 0; i < cartasEspeciales.size(); i++){
            
            if(sorpresa == cartasEspeciales.get(i)){
                sorpresas.add(cartasEspeciales.get(i));
                cartasEspeciales.remove(i);
                
                Diario.getInstance().ocurreEvento("Se ha movido una carta especial al mazo");
            }
        }
    }
    
    Sorpresa getUltimaSorpresa(){
        return ultimaSorpresa;
    }
}
