/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;
import java.util.Collections;
    

/**
 *
 * @author celss
 */
public class CivitasJuego {
    private int indiceJugadorActual;
    private MazoSorpresas mazo;
    private Tablero tablero;
    private ArrayList<Jugador> jugadores;
    private EstadosJuego estado;
    private GestorEstados gestorEstados;
    
    private void avanzaJugador(){
         Jugador jugadorActual = getJugadorActual();        
         int posicionActual = jugadorActual.getNumCasillaActual();        
         int tirada = Dado.getInstance().tirar();        
         int posicionNueva = tablero.nuevaPosicion(posicionActual, tirada);        
         Casilla casilla = tablero.getCasilla(posicionNueva);        
         contabilizarPasosPorSalida(jugadorActual);        
         jugadorActual.moverACasilla(posicionNueva);        
         casilla.recibeJugador(indiceJugadorActual, jugadores);        
         contabilizarPasosPorSalida(jugadorActual);
    }
    
    public Boolean cancelarHipoteca(int ip){
        return jugadores.get(indiceJugadorActual).cancelarHipoteca(ip);
    }
    
    public CivitasJuego(ArrayList<String> nombres){
        jugadores = new ArrayList<>();        
        for (int i = 0; i < nombres.size(); i++){            
            Jugador jugador = new Jugador(nombres.get(i));            
            jugadores.add(jugador);        
        }        
        gestorEstados = new GestorEstados();        
        estado = gestorEstados.estadoInicial();        
        indiceJugadorActual = Dado.getInstance().quienEmpieza(jugadores.size());        
        mazo = new MazoSorpresas();        
        inicializarTablero(mazo);        
        inicializarMazoSorpresas(tablero);
    }
    
    public Boolean comprar(){
         Jugador jugadorActual = jugadores.get(indiceJugadorActual);        
         int numCasillaActual = jugadorActual.getNumCasillaActual();        
         Casilla casilla = tablero.getCasilla(numCasillaActual);        
         CasillaCalle calle = (CasillaCalle)casilla;        
         TituloPropiedad titulo = calle.getTituloPropiedad();        
         if (titulo.tienePropietario()){            
             System.out.println("Esta casilla ya tiene propietario y por tanto no puede ser comprada nuevamente");
             return false;
         }
         else{
             return jugadorActual.comprar(titulo);
         }
    }
    
    public Boolean construirCasa(int ip){
        return  jugadores.get(indiceJugadorActual).construirCasa(ip);
    }
    
    public Boolean construirHotel(int ip){
        return  jugadores.get(indiceJugadorActual).construirHotel(ip);
    }
    
    private void contabilizarPasosPorSalida(Jugador jugadorActual){
        if(tablero.getPorSalida() > 0){
            jugadorActual.pasaPorSalida();
        }
    }
    
    public Boolean finalDelJuego(){
        for (int i = 0; i < jugadores.size(); i++){            
            if (jugadores.get(i).enBancarrota()){                
                return true;
            }            
        }
        return false;
    }
    
    public Casilla getCasillaActual(){
         return tablero.getCasilla(jugadores.get(indiceJugadorActual).getNumCasillaActual());
    }
    
    public Jugador getJugadorActual(){
         return jugadores.get(indiceJugadorActual);
    }
    
    public Boolean hipotecar(int ip){
        return jugadores.get(indiceJugadorActual).hipotecar(ip);
    }
    
    public String infoJugadortexto(){
        return jugadores.get(indiceJugadorActual).toString();
    }
    
    private void inicializarMazoSorpresas(Tablero tablero){
         mazo.alMazo(new SorpresaIrCarcel(tablero));        
         mazo.alMazo(new SorpresaIrACasilla(tablero, 18, "Debes ir a la casilla 18"));        
         mazo.alMazo(new SorpresaIrACasilla(tablero, 2, "Debes ir a la casilla 2"));        
         mazo.alMazo(new SorpresaSalirCarcel(mazo));        
         mazo.alMazo(new SorpresaPagarCobrar(200, "Has ganado el concurso de belleza, ganas 200 euros"));        
         mazo.alMazo(new SorpresaPagarCobrar(-100, "Exceso de velocidad, pagas 100 euros de multa"));        
         mazo.alMazo(new SorpresaPorCasaHotel(100, "Ganas 100 euros por cada casa u hotel"));        
         mazo.alMazo(new SorpresaPorCasaHotel(-50, "Pagas 50 euros por cada casa u hotel"));        
         mazo.alMazo(new SorpresaPorJugador(100, "Cada jugador te dona 100 euros"));        
         mazo.alMazo(new SorpresaPorJugador(-50, "Debes pagar 50 euros a cada jugador"));        
         mazo.alMazo(new SorpresaEspeculador(300));
    }
    
    private void inicializarTablero(MazoSorpresas mazo){
        tablero = new Tablero(5);                
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 1", 50, 10, 150, 500, 250)));       
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 2", 52, 10, 200, 525, 275)));         
        tablero.añadeCasilla(new CasillaSorpresa(mazo, "Sorpresa"));         
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 4", 55, 11, 300, 550, 300)));
        //CARCEL (N5)
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 6", 60, 12, 400, 600, 350))); 
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 7", 65, 13, 450, 650, 400)));
        tablero.añadeCasilla(new CasillaSorpresa(mazo, "Sorpresa"));         
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 9", 70, 14, 500, 700, 450)));         
        tablero.añadeCasilla(new Casilla("Parking"));         
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 11", 75, 15, 600, 750, 500)));         
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 12", 80, 16, 650, 800, 550)));         
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 13", 85, 17, 700, 850, 600)));         
        tablero.añadeCasilla(new CasillaSorpresa(mazo, "Sorpresa"));         
        tablero.añadeCasilla(new CasillaJuez(tablero.getCarcel(), "Juez"));
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 16", 90, 18, 800, 900, 650)));       
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 17", 95, 19, 900, 950, 700)));         
        tablero.añadeCasilla(new CasillaImpuesto(200, "Impuesto"));         
        tablero.añadeCasilla(new CasillaCalle(new TituloPropiedad("Calle 19", 100, 20, 1000, 750, 1000))); 
    }
    
    private void pasarTurno(){
        indiceJugadorActual = (indiceJugadorActual + 1) % jugadores.size();
    }
    
    public ArrayList<Jugador> ranking(){
         ArrayList<Jugador> aux = jugadores;        
         Collections.sort(aux, Collections.reverseOrder());        
         return aux;
    }
    
    public Boolean salirCarcelPagando(){
        return jugadores.get(indiceJugadorActual).salirCarcelPagando();
    }
    
    public Boolean salirCarcelTirando(){
        return jugadores.get(indiceJugadorActual).salirCarcelTirando();
    }
    
    public OperacionesJuego siguientePaso(){
        Jugador jugadorActual = jugadores.get(indiceJugadorActual);        
        OperacionesJuego operacion = gestorEstados.operacionesPermitidas(jugadorActual, estado);        
        if (operacion == OperacionesJuego.PASAR_TURNO){            
            pasarTurno();            
            siguientePasoCompletado(operacion);        
        } 
        else if (operacion == OperacionesJuego.AVANZAR){            
            avanzaJugador();            
            siguientePasoCompletado(operacion);        
        }        
        return operacion;
    }
    
    public void siguientePasoCompletado(OperacionesJuego operacion){
        estado = gestorEstados.siguienteEstado(jugadores.get(indiceJugadorActual), estado, operacion);
    }
    
    public Boolean vender(int ip){
        return jugadores.get(indiceJugadorActual).vender(ip);
    }
}
