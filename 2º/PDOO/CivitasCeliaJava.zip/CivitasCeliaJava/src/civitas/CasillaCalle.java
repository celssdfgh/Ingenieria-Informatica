/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author celss
 */
public class CasillaCalle extends Casilla{
    private float importe;
    private TituloPropiedad tituloPropiedad;
    
    CasillaCalle(TituloPropiedad titulo){
        super(titulo.getNombre());
        importe = titulo.getPrecioCompra();
        tituloPropiedad = titulo;
    }
    
    TituloPropiedad getTituloPropiedad(){
        return tituloPropiedad;
    }
    
    @Override
    public void recibeJugador(int actual, ArrayList<Jugador> todos){
        if (super.jugadorCorrecto(actual, todos)){            
            super.informe(actual, todos);            
            if (tituloPropiedad.tienePropietario() == false){                
                todos.get(actual).puedeComprarCasilla();                
                todos.get(actual).puedeComprar = true;            
            } 
            else {                
                tituloPropiedad.tramitarAlquiler(todos.get(actual));                
                todos.get(actual).puedeComprar = false;            
            }        
        } 
    }
    
    @Override
    public String toString(){
        return "Casilla{ nombre=" + super.getNombre() + ", importe=" + importe + " }";
    }
}
