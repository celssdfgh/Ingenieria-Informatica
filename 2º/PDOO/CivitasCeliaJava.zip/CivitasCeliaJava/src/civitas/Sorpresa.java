/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author celss
 */
public abstract class Sorpresa {
    private String texto;
    
    Sorpresa(String texto){
        this.texto = texto;
    }
    
    String getTexto(){
        return texto;
    }
    
    public Boolean jugadorCorrecto(int actual, ArrayList<Jugador> todos){
        return (actual < todos.size() && actual >= 0);
    }
    
    void informe(int actual, ArrayList<Jugador> todos){
        Diario.getInstance().ocurreEvento("Aplicando sorpresa a " + todos.get(actual).getNombre());
    }
    
    abstract void aplicarAJugador(int actual, ArrayList<Jugador> todos);
    
    @Override
    public String toString(){
        return "Sorpresa{" + "texto=" + texto + "}";
    }
    
}
