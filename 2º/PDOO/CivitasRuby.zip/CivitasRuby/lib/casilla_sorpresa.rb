# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class CasillaSorpresa < Casilla
  
  def initialize(mazo,nombre)
    super(nombre)
    @mazo = mazo
  end
  
  def to_string
    str = "-------Casilla : #{@nombre} --------- \n"
    return str
  end
  
  def recibe_jugador(actual,todos)
    if(jugador_correcto(actual,todos))
      s = @mazo.siguiente
      super(actual,todos)
      s.aplicar_a_jugador(actual,todos)
    end
  end
  
  public :to_string
end
end
