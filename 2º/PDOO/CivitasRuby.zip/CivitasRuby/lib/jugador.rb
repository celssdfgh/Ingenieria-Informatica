# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class Jugador
  include Comparable
  attr_reader :nombre, :numCasillaActual, :CasasPorHotel, :propiedades, :puedeComprar, :saldo, :CasasMax, :valor, :encarcelado, :especulador, :salvoconducto
  
  def jugador_por_copia(otro)
    @nombre = otro.nombre
    @propiedades = otro.propiedades
    
    for i in @propiedades
      i.actualizar_propietario_por_conversion(self)
    end
    
    @salvoconducto = otro.salvoconducto
    @encarcelado = otro.encarcelado
    @numCasillaActual = otro.numCasillaActual
    @puedeComprar = otro.puedeComprar
    @saldo = otro.saldo
    @especulador = otro.especulador
  end
  
  def initialize(nombre1)
    @nombre = nombre1
    @encarcelado = false
    @numCasillaActual = 0;
    @puedeComprar = true
    @propiedades = Array.new 
    @salvoconducto = nil
    @especulador = false
    @saldo = 7500
    
    @@CasasMax = 4
    @@CasaPorHotel = 4
    @@HotelesMax = 4
    @@PasoPorSalida = 1000
    @@PrecioLibertad = 200
    @@SaldoInicial = 7500
  end
  
  def self.copia(otro)
    @nombre = otro.nombre
    @propiedades = otro.propiedades
    @salvoconducto = otro.salvoconducto
    @encarcelado = otro.encarcelado
    @numCasillaActual = otro.numCasillaActual
    @puedeComprar = otro.puedeComprar
    @saldo = otro.saldo
  end
  
  def is_encarcelado
    return @encarcelado
  end
  
  def debe_ser_encarcelado
    if(is_encarcelado)
      return false
    else
      if(!tiene_salvoconducto)
        return true
      else
        perder_salvoconducto
        Diario.instance.ocurre_evento("El jugador" + @nombre + "se libra de la carcel. Pierde salvoconducto")
        return false
      end
    end
  end
  
  def encarcelar(n_casilla_carcel)
    if(debe_ser_encarcelado)
      mover_a_casilla(n_casilla_carcer)
      @encarcelado = true
      Diario.instance.ocurre_evento("El jugador" + @nombre + "va a la carcel")
    end
    return @encarcelado
  end
  
  def obtener_salvoconducto(s)
    if(is_encarcelado)
      return false
    else
      @salvoconducto = s
      return true
    end
  end
  
  def perder_salvoconducto
    @salvoconducto.usada
    @salvoconducto = nil
  end
  
  def tiene_salvoconducto
    if(@salvoconducto != nil)
      return true
    else
      return false
    end
  end
  
  def puede_comprar_casilla
    if(is_encarcelado)
      @puedeComprar = false
    else
      @puedeComprar = true
    end
    return @puedeComprar
  end
  
  def paga(cantidad)
    return modificar_saldo(cantidad*-1)
  end
  
  def paga_impuesto(cantidad)
    if(is_encarcelado)
      return false
    else
      return paga(cantidad)
    end
  end
  
  def paga_alquiler(cantidad)
    if(is_encarcelado)
      return false
    else
      return paga(cantidad)
    end
  end
  
  def recibe(cantidad)
    if(is_encarcelado)
      return false
    else
      return modificar_saldo(cantidad)
    end
  end
  
  def modificar_saldo(cantidad)
    @saldo = @saldo + cantidad
    Diario.instance.ocurre_evento("Saldo modificado")
    return true
  end
  
  def mover_a_casilla(nCasilla)
    if(is_encarcelado)
      return false
    else
      @numCasillaActual = nCasilla
      @puedeComprar = false
      Diario.instance.ocurre_evento("El jugador " + @nombre + "ha sido movido de casilla a " + @numCasillaActual)
      return true
    end
  end
  
  def puedo_gastar(precio)
    if(is_encarcelado)
      return false
    else
      return @saldo >= precio
    end
  end
  
  def vender(ip)
    if(is_encarcelado)
      return false
    else
      if(existe_la_propiedad(ip))
        aux = @propiedades[ip].vender(self)
        if(aux)
          Diario.instance.ocurre_evento("El jugador " + @nombre + "ha vendido la propiedad " + @propiedades[ip].nombre)
          @propiedades.delete_at(ip)
          return true
        else
          return false
        end
      else
        return false
      end
    end
  end
  
  def tiene_algo_que_gestionar
    if(@propiedades.size > 0)
      return true
    else
      return false
    end
  end
  
  def puede_salir_carcel_pagando
    if(@saldo >= @@PrecioLibertad)
      return true
    else
      return false
    end
  end
  
  def salir_carcel_pagando
    if(is_encarcelado && puede_salir_carcel_pagando)
      paga(@@PrecioLibertad)
      @encarcelado = false
      Diario.instance.ocurre_evento("El jugador " + @nombre + "sale de la carcel pagando")
      return true
    else
      return false
    end
  end
  
  def salir_carcel_tirando
    if(Dado.instance.salgo_de_la_carcel)
      @encarcelado = false
      Diario.instance.ocurre_evento("El jugador " + @nombre + "sale de la carcel tirando")
      return true
    else
      return false
    end
  end
  
  def pasa_por_salida
    modificar_saldo(@@PasoPorSalida)
    Diario.instance.ocurre_evento("El jugador " + @nombre + "pasa por salida")
    return true
  end
  
  def <=>(otro)
    @valor <=> otro.valor
  end
  
  def cancelar_hipoteca(ip)
    result = false
    
    if(@encarcelado)
      return result
    end
    
    if(existe_la_propiedad(ip))
      propiedad = @propiedades[ip]
      cantidad = propiedad.get_importe_cancelar_hipoteca
      puedo_gastar = puedo_gastar(cantidad)
      
      if(puedo_gastar)
        result = propiedad.cancelar_hipoteca(self)
        if(result)
          Diario.instance.ocurre_evento(@nombre + " ha cancelado la hipoteca")
        end
      end
    end
    return result
  end
  
  def comprar(titulo)
    result = false
    
    if(@encarcelado)
      return result
    end
    
    if(@puedeComprar)
      precio = titulo.precioCompra
      if(puedo_gastar(precio))
        result = titulo.comprar(self)
        if(result)
          @propiedades << titulo
          Diario.instance.ocurre_evento("Propiedad " + titulo.to_string + "comprada por " + @nombre)
        end
        @puedeComprar = false
      end
    end
    return result
  end
  
  def construir_hotel(ip)
    result = false
    
    if(@encarcelado)
      return result
    end
    
    if(existe_la_propiedad(ip))
      propiedad = @propiedades[ip]
      puedo_edificar_hotel = puedo_edificar_hotel(propiedad)
      precio = propiedad.precioedificar
      
      if(puedo_gastar(precio) && propiedad.nHoteles < @@HotelesMax && propiedad.nCasas >= @@CasasPorHotel)
        puedo_edificar_hotel = true
      end
      if(puedo_edificar_hotel)
        result = propiedad.construir_hotel(self)
        propiedad.derruir_casas(@@CasasPorHotel, self)
        Diario.instance.ocurre_evento(@nombre + "ha construido un hotel en " + ip.to_s)
      end
    end
    return result
  end
  
  def construir_casa(ip)
    result = false
    
    if(@encarcelado)
      return result
    else
      existe = existe_la_propiedad(ip)
      if(existe)
        propiedad = @propiedades[ip]
        puedo_edificar_casa = puedo_edificar_casa(propiedad)
        if(puedo_edificar_casa)
          result = propiedad.construir_casa(self)
          if(result)
            Diario.instance.ocurre_evento(@nombre + " ha construido una casa en " + ip.to_s)
          end
        end
      end
    end
    return result
  end
  
  def hipotecar(ip)
    result=false
    
    if(@encarcelado)
      return result
    end
    
    if(existe_la_propiedad(ip))
      propiedad = @propiedades[ip]
      result = propiedad.hipotecar(self)
    end
    if(result)
      Diario.instance.ocurre_evento(@nombre + " hipoteca la propiedad " + ip.to_s)
    end
    return result
  end
  
  def get_num_casilla_actual
    return @numCasillaActual
  end
  
  def existe_la_propiedad(ip)
    if(ip >= 0 && ip < @propiedades.size)
      return true
    else
      return false
    end
  end
  
  def cantidad_casas_hoteles
    c = 0
    for i in 0...@propiedades.size
      c = c + @propiedades[i].cantidad_casas_hoteles
    end
    return c
  end
  
  def en_bancarrota
    if(@saldo <= 0)
      return true
    else
      return false
    end
  end
  
  def get_casas_max
    return @@CasasMax
  end
  
  def get_hoteles_max
    return @@HotelesMax
  end
  
  def get_casas_por_hotel
    return @@CasasPorHotel
  end
  
  def get_precio_libertad
    return @@PrecioLibertad
  end
  
  def get_premio_paso_salida
    return @@PasoPorSalida
  end
  
  def get_nombre_propiedades
    n = Array.new 
    for i in 0...@propiedades.size
      n << @propiedades[i].nombre
    end
    return n
  end
  
  def get_puede_comprar
    return @puedeComprar
  end
  
  def get_saldo
    return @saldo
  end
  
  def puedo_edificar_casa(propiedad)
    if(@encarcelado)
      return false
    end
    
    if(propiedad.nCasas <= @@CasasMax)
      return @saldo >= propiedad.precioedificar
    else
      return false
    end
  end
  
  def puedo_edificar_hotel(propiedad)
    if(@encarcelado)
      return false
    end
    
    if(propiedad.nHoteles <= @@HotelesMax && propiedad.nCasas==4)
      return @saldo >= propiedad.precioedificar
    else
      return false
    end
  end
  
  def to_string
    cadena = "Jugador: [ " + "encarcelado = " + @encarcelado.to_s + ", nombre = " + @nombre + ", puede comprar = " + @puedeComprar.to_s + ", numero casilla actual = " + @numCasillaActual.to_s + ", saldo = " + @saldo.to_s + ", salvoconducto = " + tiene_salvoconducto.to_s + "]"
    cadena2 = "Propiedades: [ "
    for i in 0...@propiedades.size
      cadena2 = cadena2 + @propiedades[i].nombre
    end
    cadena_final = cadena + cadena2
    return cadena_final
  end
  
  private :perder_salvoconducto, :puedo_gastar, :CasasPorHotel, :puedo_edificar_hotel, :puedo_edificar_casa, :puede_salir_carcel_pagando, :existe_la_propiedad
end
end
