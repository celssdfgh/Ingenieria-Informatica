# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class SorpresaIrCasilla < Sorpresa
  
  def initialize(tablero1, valor1, texto)
    super(texto)
    @tablero = tablero1
    @valor = valor1
  end
  
  def to_string 
    return "Sorpresa Ir a Casilla"
  end
  
  def aplicar_a_jugador(actual,todos)
    if(jugador_correcto(actual,todos))
      super(actual,todos)
      cActual = todos[actual].numCasillaActual
      tirada = @tablero.calcula_tirada(cActual, @valor)
      npos = @tablero.nueva_pos(cActual, tirada)
      todos[actual].mover_a_casilla(npos)
      @tablero.get_casilla(npos).recibe_jugador(actual,todos)
    end
  end
  
  public_class_method :new
end
end
