# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative ('casilla.rb')

module Civitas
  class Tablero
    
    attr_reader :numCasillaCarcel
    
    def initialize(indice)
      if(indice < 1)
        numCasillaCarcel = 1
      else
        numCasillaCarcel = indice
      end
      
      @casillas = Array.new 
      @casillas << Casilla.new("Salida")
      @porSalida = 0
      @tieneJuez = false
    end

    
    def correcto(nCasillas)
      if(nCasillas && @casillas.size > nCasillas && nCasillas >= 0 && @tieneJuez)
        return true  
      else
        return false
      end
    end
    
    def get_carcel
      return numCasillaCarcel
    end
    
    def get_porSalida()
      if(@porSalida > 0)
        salida = @porSalida
        @porSalida = @porSalida - 1
        return salida
      else
        return @porSalida
      end
    end
    
    def add_casilla(casilla)
      if(@casillas.size == @numCasillaCarcel)
        @casillas << Casilla.new("Carcel")
        @casillas << casilla
      else
        @casillas<<casilla
      end
    end
    
    def add_juez()
      if(!@tieneJuez)
        @casillas<<CasillaJuez.new("juez",@numCasillaCarcel)
        @tieneJuez = true
      end
    end
    
    def get_casilla(nCasilla)
      if(correcto(nCasilla))
        return @casillas[nCasilla]
      else
        return nil
      end
    end
    
    def nueva_pos(actual,tirada)
      if(correcto())
        y=(actual+tirada)%@casillas.size
        x=actual+tirada
        if(x==y)
          return x
        else
          return y
        end
      else
        return -1
      end
    end
    
    def calcula_tirada(origen,destino)
      tirada = destino - origen
      if(tirada < 0)
        porSalida = porSalida + 1
        return @casillas.size + tirada
      else
        return tirada
      end
    end
    
    private :correcto
    
  end
    
end
