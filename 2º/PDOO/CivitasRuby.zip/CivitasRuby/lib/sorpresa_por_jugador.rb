# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class SorpresaPorJugador < Sorpresa
  
  def initialize(valor1, texto)
    super(texto)
    @valor = valor1
  end
  
  def to_string
    return "Sorpresa Aplicar A Jugador"
  end
  
  def aplicar_a_jugador(actual, todos)
    if(jugador_correcto(actual,todos))
      super(actual,todos)
      a = SorpresaPagarCobrar(@valor*-1, "Pagan todos")
      b = SorpresaPagarCobrar(@valor*t(odos.size-1), "Recibe dinero")
      
      for i in 0...todos.size
        if(actual != i)
          a.aplicar_a_jugador(i,todos)
        else
          b.aplicar_a_jugador(i,todos)
        end
      end
    end
  end
  
  public_class_method :new
end
end
