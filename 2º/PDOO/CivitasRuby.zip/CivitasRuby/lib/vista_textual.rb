#encoding:utf-8
require_relative 'operaciones_juego'
require_relative 'gestiones_inmobiliarias'
require_relative 'salidas_carcel'
require_relative 'respuestas'
require_relative 'civitas_juego'
require_relative 'operacion_inmobiliaria'

require 'io/console'

module Civitas

  class Vista_textual
    
    attr_reader :iGestion

    def mostrar_estado(estado)
      puts estado
    end

    
    def pausa
      print "Pulsa una tecla"
      STDIN.getch
      print "\n"
    end

    def lee_entero(max,msg1,msg2)
      ok = false
      begin
        print msg1
        cadena = gets.chomp
        begin
          if (cadena =~ /\A\d+\Z/)
            numero = cadena.to_i
            ok = true
          else
            raise IOError
          end
        rescue IOError
          puts msg2
        end
        if (ok)
          if (numero >= max)
            ok = false
          end
        end
      end while (!ok)

      return numero
    end



    def menu(titulo,lista)
      tab = "  "
      puts titulo
      index = 0
      lista.each { |l|
        puts tab+index.to_s+"-"+l
        index += 1
      }

      opcion = lee_entero(lista.length,
                          "\n"+tab+"Elige una opción: ",
                          tab+"Valor erróneo")
      return opcion
    end

    
    def comprar
      opcionesmenu = [Civitas::Respuestas::SI.to_s, Civitas::Respuestas::NO.to_s]
      opcion = menu("¿Quieres comprar esta casilla?", opcionesmenu)
      return Civitas::Respuestas::Lista_respuestas[opcion]
    end

    def gestionar
      opcionesgestiones = [Civitas::GestionesInmobiliarias::VENDER.to_s, Civitas::GestionesInmobiliarias::TERMINAR.to_s, Civitas::GestionesInmobiliarias::HIPOTECAR.to_s,       opcionesgestiones = Civitas::GestionesInmobiliarias::VENDER.to_s, Civitas::GestionesInmobiliarias::TERMINAR.to_s, Civitas::GestionesInmobiliarias::HIPOTECAR.to_s,opcionesgestiones = Civitas::GestionesInmobiliarias::CONSTRUIR_HOTEL.to_s, Civitas::GestionesInmobiliarias::CONSTRUIR_CASA.to_s]
      opcion = menu("¿Que gestion quieres hacer?", opcionesgestiones)
      o = @juegoModel.get_jugador_actual.get_nombre_propiedades
      @iGestion = opcion
      
      if(opcion != 5 && o != nill)
        indice = menu("¿Sobre que propiedad quieres realizar esta gestion?", o)
      end
       
      @iPropiedad = indice
    end

    def getGestion
      return @iGestion
    end

    def getPropiedad
      return @iPropiedad
    end

    def mostrarSiguienteOperacion(operacion)
      if(operacion == Civitas::Operaciones_juego::AVANZAR)
        puts "Siguiente operacion: Avanzar."
      end
      if(operacion == Civitas::Operaciones_juego::COMPRAR)
        puts "Siguiente operacion: Comprar."
      end
      if(operacion == Civitas::Operaciones_juego::GESTIONAR)
        puts "Siguiente operacion: Gestionar."
      end
      if(operacion == Civitas::Operaciones_juego::PASAR_TURNO)
        puts "Siguiente operacion: Pasar turno."
      end
      if(operacion == Civitas::Operaciones_juego::SALIR_CARCEL)
        puts "Siguiente operacion: Salir de la carcel."
      end
    end

    def mostrarEventos
      while(Diario.instance.eventos_pendientes)
        pendientes = Diario.instance.leer_evento
        puts pendientes
      end
    end

    def set_civitas_juego(civitas)
         @juegoModel=civitas
    end

    def actualizarVista
      a = @juegoModel.info_jugador_texto
      b = @juegoModel.get_casilla_actual.to_string
      puts a + " - " + b
    end

    
  end

end
