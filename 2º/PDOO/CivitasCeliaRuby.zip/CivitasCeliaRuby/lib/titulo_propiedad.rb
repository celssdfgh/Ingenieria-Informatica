# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class Titulo_propiedad
  
  attr_reader :nombre, :nCasas, :nHoteles, :hipotecado, :propietario, :preciocompra, :precioedificar
  
  def initialize(n,pba,fr,phb,pc,ppe)
    @nombre = n
    @alquilerBase = pba
    @factorRevalorizacion = fr
    @hipotecaBase = phb
    @precioCompra = pc
    @precioEdificar = ppe
    
    @propietario = nil
    @nCasas = 0
    @nHoteles = 0
    @hipotecado = false
    @@factorInteresesHipoteca = 1.1
  end
  
  def to_string
    return  "--------PROPIEDAD---------\n
    Nombre: #{@nombre}
    Alquiler base: #{@alquilerBase}
    Numero de casas: #{@nCasas}
    Numero de hoteles: #{@nHoteles}
    Precio de compra: #{@precioCompra}"
  end
  
  def tiene_propietario
    if(@hipotecado)
      return true
    else
      return false
    end
  end
  
  def propietario_encarcelado
    return (!(!@propietario.is_encarcelado||!tiene_propietario))
  end
  
  def get_precioalquiler
    if(@hipotecado || propietario_encarcelado)
      alquiler = 0
    else
      alquiler = (@alquilerBase*(1+(@nCasas*0.5)+(@nHoteles*2.5)))
    end
    return p
  end
  
  def get_importehipoteca
    cantidad = (@hipotecaBase*(1+(@nCasas*0.5)+(@nHoteles*2.5)))
    return cantidad
  end
  
  def get_importecancelarhipoteca
    return get_importehipoteca*@@fatorInteresesHipoteca
  end
  
  def es_este_el_propietario(jugador)
    return @propietario.equal?(jugador)
  end
  
  def tramitar_alquiler(jugador)
    if(tiene_propietario && !es_este_el_propietario(j))
      jugador.paga_alquiler(get_precioalquiler)
      @propietario.recibe(get_precioalquiler)
    end
  end
  
  def cantidad_CasasHoteles
    return @nCasas+@nHoteles
  end
  
  def get_precioventa
    return @precioCompra+(@nCasas+5*@nHoteles)*@precioEdificar*@factorRevalorizacion
  end
  
  def derruir_casas(n,jugador)
    if(es_este_el_propietario(jugador)&&@nCasas >= n)
      @nCasas = @nCasas - n
      return true
    else
      return false
    end
  end
  
  def vender(jugador)
    if(!es_este_el_propietario(jugador))
      return false
    else
      @propietario.recibe(get_precioventa)
      @propietario = nil
      @nCasas = 0
      @nHoteles = 0
      return true
    end
  end
  
  def cancelar_hipoteca(jugador)
    if(@hipotecado && es_este_el_propietario(jugador))
      if(jugador.paga(get_importe_cancelar_hipoteca))
        @hipotecado = false
        return true
      else
        return false
      end
      return false
    end
  end
  
  def hipotecar(jugador)
    if(!@hipotecado && es_este_el_propietario(jugador))
      if(jugador.recibe(get_importehipoteca))
        @hipotecado = true
        return true
      else
        return false
      end
    else
      return false
    end
  end
  
  def comprar(jugador)
    if(tiene_propietario)
      return false
    else
      @propietario = jugador
      @propietario.paga(@precioCompra)
      return true;
    end
  end
  
  def construir_casa(jugador)
    if(es_este_el_propietario(jugador) && @nCasas < jugador.get_casas_max)
      jugador.paga(@precioEdificar)
      @nCasas = @nCasas + 1
      return true
    else
      return false
    end
  end
  
  def construir_hotel(jugador)
    if(es_este_el_propietario(jugador) && @nHoteles < jugador.get_hoteles_max)
      jugador.paga(@precioEdificar*5)
      @nHoteles = @nHoteles + 1
      return true
    else
      return false
    end
  end
  
  def actualizar_propietario_por_conversion(jugador)
    @propietario = jugador
  end
  
  def set_propietario(jugador)
    @propietario = jugador
  end
  
  private :get_precioalquiler, :propietario_encarcelado, :es_este_el_propietario, :get_precioventa
  
end
end
