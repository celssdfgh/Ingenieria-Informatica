# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'civitas_juego.rb'
require_relative 'gestiones_inmobiliarias.rb'
require_relative 'operacion_inmobiliaria.rb'
require_relative 'operaciones_juego.rb'
require_relative 'respuestas.rb'
require_relative 'salidas_carcel.rb'

module Civitas
class Controlador
  
  def initialize(juego, vista)
    @juego = juego
    @vista = vista
  end
  
  def juega
    
    @vista.set_civitas_juego(@juego)
    
    while(!@juego.final_del_juego)
      @vista.actualizarVista
      @vista.pausa
      siguiente = @juego.siguiente_paso
      @vista.mostrarSiguienteOperacion(siguiente)
      
      if(siguiente != Civitas::Operaciones_juego::PASAR_TURNO)
        @vista.mostrarEventos
      end
      
      if(!@juego.final_del_juego)
        if(siguiente == Civitas::Operaciones_juego::COMPRAR)
          if(@vista.comprar == Civitas::Respuestas::SI)
            @juego.comprar
          end
          @juego.siguiente_paso_completado(siguiente)
        else if(siguiente == Civitas::Operaciones_juego::GESTIONAR)
            @vista.gestionar
            @vista.iGestio
            @vista.iPropiedad
            lista = [Civitas::GestionesInmobiliarias::VENDER,Civitas::GestionesInmobiliarias::HIPOTECAR,Civitas::GestionesInmobiliarias::CANCELAR_HIPOTECA,Civitas::GestionesInmobiliarias::CONSTRUIR_CASA,Civitas::GestionesInmobiliarias::CONSTRUIR_HOTEL,Civitas::GestionesInmobiliarias::TERMINAR]
            operacion = OperacionInmobiliaria.new(lista[@vista.iGestio],@vista.iPropiedad)
            
            case lista[@vista.iGestion]
            when GestionesInmobiliarias::VENDER
              if(!@juego.get_jugador_actual.get_nombre_propiedades != nil)
                @juego.vender(operacion.numPropiedad)
              end
              
            when GestionesInmobiliarias::HIPOTECAR
              if(!@juego.get_jugador_actual.get_nombre_propiedades != nil)
                @juego.hipotecar(operacion.numPropiedad)
              end
              
            when GestionesInmobiliarias::CANCELAR_HIPOTECAA
              if(!@juego.get_jugador_actual.get_nombre_propiedades != nil)
                @juego.cancelar_hipoteca(operacion.numPropiedad)
              end
              
            when GestionesInmobiliarias::CONSTRUIR_CASA
              @juego.construir_casa(operacion.numPropiedad)
            
            when GestionesInmobiliarias::CONSTRUIR_HOTEL
              @juego.contruir_hotel(operacion.numPropiedad)
            else
              @juego.siguiente_paso_completado
             
            end
        else if(siguiente == Operaciones_juego::SALIR_CARCEL)
            salida = @vista.salir_carcel
            if(salida == SalidasCarcel::PAGANDO)
              @juego.salir_carcel_pagando
            else
              @juego.salir_carcel_tirando
            end
            @juego.siguiente_paso_completado(siguiente)
        end          
          
        end
    
        end
      else
        posiciones = Array.new
        posiciones = @juego.ranking
        posiciones.reverse
        for i in 0...posiciones.size
          puts posiciones[i].nombre + "\n"
        end
      end
      
    end
  end
end
end

