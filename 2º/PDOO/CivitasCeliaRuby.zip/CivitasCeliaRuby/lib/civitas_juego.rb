# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'dado.rb'
require_relative 'jugador.rb'
require_relative 'mazo_sorpresas.rb'
require_relative 'gestor_estados.rb'
require_relative 'casilla.rb'
require_relative 'casilla_calle.rb'
require_relative 'casilla_impuesto.rb'
require_relative 'casilla_sorpresa.rb'
require_relative 'casilla_juez'
require_relative 'tablero.rb'
require_relative 'titulo_propiedad.rb'
require_relative 'sorpresa.rb'
require_relative 'sorpresa_ir_carcel.rb'
require_relative 'sorpresa_ir_casilla.rb'
require_relative 'sorpresa_salir_carcel.rb'
require_relative 'sorpresa_pagar_cobrar.rb'
require_relative 'sorpresa_jugador_especulador.rb'
require_relative 'sorpresa_por_casa_hotel.rb'
require_relative 'sorpresa_por_jugador.rb'

module Civitas
class CivitasJuego
  
  def initialize(nombres)
    @jugadores = Array.new
    for i in 0...nombres.size
      @jugadores << Jugador.new(nombres[i])
    end
    
    @gestorEstados = Gestor_estados.new
    @estado = @gestorEstados.estado_inicial
    @indiceJugadorActual = Dado.instance.quien_empieza(@jugadores.size)
    @mazo = Mazo_sorpresas.new 
    inicializa_tablero(@mazo)
    inicializa_mazo_sorpresas(@tablero)
  end
  
  def inicializa_tablero(mazo)
    @tablero = Tablero.new(6)
    @mazo = mazo
    
    propiedad1 = Titulo_propiedad.new("Camino de Ronda",100,1.20,150,250,50)
    casilla1 = CasillaCalle.new("Camino de Ronda",propiedad1)
    @tablero.add_casilla(casilla1)
    
    propiedad2 = Titulo_propiedad.new("Recogidas",85,1.30,200,300,70)
    casilla2 = CasillaCalle.new("Recogidas",propiedad2)
    @tablero.add_casilla(casilla2)
    
    propiedad3 = Titulo_propiedad.new("Plaza Nueva",95,1.90,120,490,20)
    casilla3 = CasillaCalle.new("Plaza Nueva",propiedad3)
    @tablero.add_casilla(casilla3)
    
    propiedad4 = Titulo_propiedad.new("Arabial",200,1,100,440,55)
    casilla4 = CasillaCalle.new("Arabial",propiedad4)
    @tablero.add_casilla(casilla4)
    
    propiedad5 = Titulo_propiedad.new("Puentezuelas",150,1.40,250,350,75)
    casilla5 = CasillaCalle.new("Puentezuelas",propiedad5)
    @tablero.add_casilla(casilla5)
    
    propiedad6 = Titulo_propiedad.new("Mesones",1200,1.70,2000,2400,1000)
    casilla6 = CasillaCalle.new("Mesones",propiedad6)
    @tablero.add_casilla(casilla6)
    
    propiedad7 = Titulo_propiedad.new("Ganivet",700,1.10,1800,2100,900)
    casilla7 = CasillaCalle.new("Ganivet",propiedad7)
    @tablero.add_casilla(casilla7)
    
    propiedad8 = Titulo_propiedad.new("Gonzalo Gallas",500,1.80,1500,1600,400)
    casilla8 = CasillaCalle.new("Gonzalo Gallas",propiedad8)
    @tablero.add_casilla(casilla8)
    
    parking = Casilla.new("Parking gratuito")
    @tablero.add_casilla(parking)
    
    s1 = CasillaSorpresa.new(@mazo, "Sorpresa")
    @tablero.add_casilla(s1)
    
    s2 = CasillaSorpresa.new(@mazo, "Sorpresa!")
    @tablero.add_casilla(s2)
    
    s3 = CasillaSorpresa.new(@mazo, "Sorpresa!!")
    @tablero.add_casilla(s3)
    
    s4 = CasillaSorpresa.new(@mazo, "Sorpresa!!!")
    @tablero.add_casilla(s4)
    
    imp1 = CasillaImpuesto.new(150.0, "Factura agua. 150$")
    @tablero.add_casilla(imp1)
    
    imp2 = CasillaImpuesto.new(300.0, "Multa por botellon")
    @tablero.add_casilla(imp2)
    
    imp3 = CasillaImpuesto.new(150.0, "Accidente de coche")
    @tablero.add_casilla(imp3)
    
    imp4 = CasillaImpuesto.new(150.0, "Multa por feo")
    @tablero.add_casilla(imp4)
    
    @tablero.add_juez
    
  end
  
  def inicializa_mazo_sorpresas(tablero)
    
    s1 = SorpresaIrCarcel.new(tablero, "VAS A LA CARCEL");
    @mazo.al_mazo(s1)
    
    s2 = SorpresaSalirCarcel.new(@mazo, "Obtienes salvoconducto");
    @mazo.al_mazo(s2)
    
    s3 = SorpresaIrCasilla.new(tablero, 5, "Muevete a la casilla 5");
    @mazo.al_mazo(s3)
    
    s4 = SorpresaIrCasilla.new(tablero, 1, "Muevete a la casilla 1");
    @mazo.al_mazo(s4)
    
    s5 = SorpresaIrCasilla.new(tablero, 8, "Muevete a la casilla 8");
    @mazo.al_mazo(s5)
    
    s6 = SorpresaPorJugador.new(+120, "Recibes 120$ de cada jugador");
    @mazo.al_mazo(s6)
    
    s7 = SorpresaPorJugador.new(-120, "Pagas 120$ a cada jugador");
    @mazo.al_mazo(s7)
    
    s8 = SorpresaPagarCobrar.new(+200, "Cobras 200$ por ser el mas guapo");
    @mazo.al_mazo(s8)
    
    s9 = SorpresaPagarCobrar.new(-200, "Tienes que pagar 200$ porque te ha pillado un radar a 200km/h");
    @mazo.al_mazo(s9)
    
    s10 = SorpresaPorCasaHotel.new(+140, "Cobras 140$ por cada casa y hotel que tengas");
    @mazo.al_mazo(s10)
    
    s11 = SorpresaPorCasaHotel.new(-140, "Tienes que pagar 140$ por cada casa y hotel que tengas");
    @mazo.al_mazo(s11)
    
  end
  
  def contabilizar_pasos_por_salida(jugadorActual)
    while(@tablero.get_porSalida > 0)
      jugadorActual.pasa_por_salida
    end
  end
  
  def pasar_turno
    @indiceJugadorActual = @indiceJugadorActual + 1
    if(@indiceJugadorActual == @jugadores.size)
      @indiceJugadorActual = 0
    end
  end
  
  def siguiente_paso_completado(operacion)
    j = @jugadores[@indiceJugadorActual]
    @estado = @gestorEstados.siguiente_estado(j, @estado, operacion)
  end
  
  def construir_casa(ip)
    j1 = @jugadores[@indiceJugadorActual]
    return j.construir_casa(ip)
  end
  
  def construir_hotel(ip)
    j2 = @jugadores[@indiceJugadorActual]
    return j2.construir_hotel(ip)
  end
  
  def vender(ip)
    j3 = @jugadores[@indiceJugadorActual]
    return j3.vender(ip)
  end
  
  def hipotecar(ip)
    j4 = @jugador[@indiceJugadorActual]
    return j4.hipotecar(ip)
  end
  
  def cancelar_hipoteca(ip)
    j5 = @jugador[@indiceJugadorActual]
    return j5.cancelar_hipoteca(ip)
  end
  
  def salir_carcel_pagando
    j6 = @jugadores[@indiceJugadorActual]
    return j6.salir_carcel_pagando
  end
  
  def salir_carcel_tirando
    j7 = @jugadores[@indiceJugadorActual]
    return j7.salir_carcel_tirando
  end
  
  def final_del_juego
    fin = false
    for i in 0...@jugadores.size
      if(@jugadores[i].en_bancarrota)
        fin = true
      end
    end
    return fin
  end
  
  def ranking
    ranking = Array.new
    for i in 0...@jugadores.lenght()-1
      ranking << @jugadores[i]
    end
    for j in 0...ranking.lenght()-2
      for k in j+1...ranking.lenght()-1
        (ranking[j].compare_to(ranking[k]) < 0)
        aux = Jugador.new(ranking[i])
        ranking.insert(j, ranking[i])
        ranking.insert(k, aux)
      end
    end
  end
  
  def avanza_jugador
    jugador_actual = @jugadores[@indiceJugadorActual]
    pos_actual = jugador_actual.numCasillaActual
    tirada = Dado.instance.tirar
    pos_nueva = @tablero.nueva_pos(pos_actual, tirada)
    casilla = @tablero.get_casilla(pos_nueva)
    contabilizar_pasos_por_salida(jugador_actual)
    jugador_actual.mover_a_casilla(pos_nueva)
    casilla.recibe_jugador(@indiceJugadorActual, @jugadores)
    contabilizar_pasos_por_salida(jugador_actual)
  end
  
  def siguiente_paso
    jugador_actual = @jugadores[@indiceJugadorActual]
    operacion = @gestorEstados.operaciones_permitidas(jugador_actual, @estado)
    
    if(operacion == Civitas::Operaciones_juego::PASAR_TURNO)
      pasar_turno
      siguiente_paso_completado(operacion)
    else if(operacion == Civitas::Operaciones_juego::AVANZAR)
        avanza_jugador
        siguiente_paso_completado(operacion)
    end
    end
  return operacion
  
  end
  
  def comprar
    jugador_actual = @jugadores[@indiceJugadorActual]
    n_casilla_actual = jugador_actual.numCasillaActual
    casilla = @tablero.get_casilla(n_casilla_actual)
    titulo = casilla.tituloPropiedad
    return jugador_actual.comprar(titulo)
  end
  
  def get_casilla_actual
    jugador1 = @jugadores[@indiceJugadorActual].numCasillaActual
    return @tablero.get_casilla(jugador1)
  end
  
  def get_jugador_actual
    return @jugadores[@indiceJugadorActual]
  end
  
  def info_jugador_texto
    return @jugadores[@indiceJugadorActual].to_string
  end
  
  private :inicializa_tablero, :inicializa_mazo_sorpresas, :avanza_jugador, :pasar_turno, :contabilizar_pasos_por_salida
  
end
end
