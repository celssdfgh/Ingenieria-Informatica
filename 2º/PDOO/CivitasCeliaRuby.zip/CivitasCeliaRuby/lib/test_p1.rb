# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative ('tablero')
require_relative ('mazo_sorpresas')
require_relative ('casilla')
require_relative ('diario')
require_relative ('dado')
require_relative ('tipo_sorpresa')
require_relative ('tipo_casilla')
require_relative ('operaciones_juego')
require_relative ('estados_juego')
require_relative ('sorpresa')
require_relative ('civitas_juego')
require_relative ('gestor_estados') 
require_relative ('jugador')
require_relative ('vista_textual')
require_relative ('controlador')
require_relative ('operacion_inmobiliaria')
require_relative ('gestiones_inmobiliarias')
require_relative ('respuestas')
require_relative ('salidas_carcel')

module Civitas
  class TestP1
    
    def self.main
      for i in 0...100
        puts "\n#{Dado.instance.quien_Empieza(4)}"
      end
    end
    
    def self.main2
      Dado.instance.set_debug(false)
      
      for i in 0...40
        puts "\n#{Dado.instance.tirar}"
      end
    end
    
    def self.main3
      Dado.instance.set_debug(false)
      
      for i in 0...100
        puts "\n#{Dado.instance.salgo_carcel}"
      end
    end
    
    def self.main4
      puts Estados_juego::DESPUES_CARCEL
    end
    
    def self.main5
      x = Mazo_sorpresas.new
      y = Sorpresa.new
      z = Sorpresa.new
      x.al_mazo(y)
      x.al_mazo(z)
      x.siguiente
      x.habilitar_cartaespecial(y)
      x.inhabilitar_cartaespecial(y)
      
    end
    
    def self.main6
      puts Diario.instance.leer_evento
      puts Diario.instance.leer_evento
    end
    
    def self.main7
      a = Tablero.new(3)
      x = Casilla.new('Celia')
      y = Casilla.new('Javi')
      z = Casilla.new('Lidia')
      m = Casilla.new('Pepe')
      
      a.add_casilla(m)
      a.add_casilla(z)
      a.add_casilla(y)
      a.add_casilla(x)
    end
    
    def self.main8
      vistatextual = Vista_textual.new
      datos=Array.new
      datos<<"Maria"
      datos<<"Juan"
      Dado.instance.set_debug(true)
      jogo = CivitasJuego.new(datos)
      controlador = Controlador.new(jogo,vistatextual)
      
      controlador.juega()
    end
    
    TestP1.main8
  end
end