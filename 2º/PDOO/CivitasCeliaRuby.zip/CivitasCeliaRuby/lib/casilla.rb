# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
#encoding:utf-8

module Civitas
class Casilla
  
  attr_reader :tituloPropiedad, :nombre
  
  def initialize(nombre)
    @nombre = nombre
  end
     
  def jugador_correcto(actual, todos)
    return actual <= todos.size
  end
  
  def informe(actual, todos)
    Diario.instance.ocurre_evento(" " + todos[actual].nombre + "ha caido en " + to_string)
  end
  
  def recibe_jugador(actual, todos)
    informe(actual,todos)
  end
  
  def nombre
    @nombre
  end
  
  def to_string
    str = "-------Casilla : #{@nombre} --------- \n"
    return str
  end
  
  private :informe
end
end
