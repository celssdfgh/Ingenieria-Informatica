# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
class Dado
  include Singleton
  
  attr_reader :ultimoResultado
  
  def initialize
    @debug = false
    @ultimoresultado = 1
    @@SalidaCarcel = 5
  end
  
  def tirar
    if(@debug)
      @ultimoresultado = 1
    else
      @ultimoresultado = 1+rand(6).to_i
    end
    return @ultimoresultado
  end
  
  def quien_empieza(a)
    n = rand(a).to_i
    return n
  end
  
  def salgo_carcel
    x = tirar
    return x>=5
  end
  
  def set_debug(deb)
    if(!deb)
      @debug = deb
      Diario.instance.ocurre_evento('Debug off')
    else
      Diario.instance.ocurre_evento('Debug on')
      @debug = deb
    end
  end
  
end
end
